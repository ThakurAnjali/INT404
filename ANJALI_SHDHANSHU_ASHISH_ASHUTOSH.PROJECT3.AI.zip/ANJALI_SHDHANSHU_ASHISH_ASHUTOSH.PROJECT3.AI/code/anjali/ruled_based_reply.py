import re                           # import re

# defining classes and their responses ->
greeting_response = ["hi", "hello", "hey"]
goodbye_response = ["bye", "talk to you later"]
event_inquiry_response = ["enter event name"]
thank_response = ['happy to help','don\'t mention it','my pleasure']
inquiry_response = ['i\'m doing ok','ok','i\'ve been better']
future_response = ['yes','no','maybe']
annual_day_response = ["Date : 10th june ,Time =10:00am"]
sports_day_response=["Date : 14th july , Time 1:00 pm onwards "]
cultural_day_response=["Date : 20 Auguest , Time 5:00pm"]
what_you_response = ['nothing', 'not much']
are_you_response = ['yes','no', 'maybe']
#when_response = ["Date : 10th june ,Time =10:00am","Date : 14th july , Time 1:00 pm onwards ","Date : 20 Auguest , Time 5:00pm","started"]
no_response = ['[No Suggestion]']

def bot_response(user_input):
    # searching patterns and making system response accordingly -->
    # greeting -->
    if re.match('hi|hi\s+there|hello|hey|good\s+[morning|afternoon|evening|day]', user_input):
        return greeting_response
    # goodbye -->
    elif re.match('goodbye|bye|see\s+ya|gotta\s+go', user_input):
        return goodbye_response
    # event_inquiry -->
elif re.match('[want|please\s+check|look\s+in]\s+event+inquiry|when\s+is\s+event', user_input):
        return event_inquiry_response
    # event_name -->
elif re.match('[when is event_name]\s+Annual day', user_input):
        return annual_day_response
    elif re.match('[when is event_name]\s+sports day', user_input):
                return sports_day_response
elif re.match('[when is event_name]\s+parents meeting', user_input):
        return cultural_day_response

    # how are you -->
    elif re.match('how\s+are\s+you.*|how.*going', user_input):
        return inquiry_response
    # thanks -->
    elif re.match('thank', user_input):
        return thank_response
    # are you -->
    elif re.match('are.*you', user_input):
        return are_you_response
    # when -->
    elif re.match('when.*you', user_input):
        return when_response
    # what's up -->
    elif re.match('sup|what.*[happening|up|you]', user_input):
        return what_you_response
    # else -->
    else:
        return no_response

print("Hello and welcome!, ask question and I will provide you with some answer to each question.")
flag = True
while flag:
    user_input = input('user:-  ').lower() # get input and convert to lowercase
    if not re.search('quit|exit', user_input):
        response = bot_response(user_input)
        for i in range(0, len(response)):

        print('Bot:- ' + response[i])
    else:
        flag = False
